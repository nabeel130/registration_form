from django.apps import AppConfig


class JobformConfig(AppConfig):
    name = 'jobform'
